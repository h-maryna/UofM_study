# SudoSlider

SudoSlider is a jQuery slider that supports any content, has effects you've only seen in image-sliders is responsive and much more.
It has a lot of transition effects, all of which are done using CSS transitions (with JavaScript fallback for old browsers).
The script doesn't force any style on your page, and you can make your navigation buttons however you like.
Just see some of the demos included in the download to get an idea of what SudoSlider can do.

http://webbies.dk/SudoSlider/

## Links

* Documentation - http://webbies.dk/SudoSlider/help/
* Build a slider - http://webbies.dk/assets/files/SudoSlider/package/sliderBuilder/
* Demos - http://webbies.dk/SudoSlider/demos.html

## HELP

* Submit an issue - https://github.com/webbiesdk/SudoSlider/issues
* Ask me - http://webbies.dk/SudoSlider/help/ask-me/
