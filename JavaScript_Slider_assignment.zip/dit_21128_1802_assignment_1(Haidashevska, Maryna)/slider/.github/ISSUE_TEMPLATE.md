Before anything else, make sure to update SudoSlider and jQuery to the latest version. Otherwise I will fart in your general direction, and maybe close the issue.

If your issue is an error report, make sure to include the following, or your issue will be ignored and/or closed
- A clear description of what happens.
- A clear description of what is supposed to happen.
- One of the following:
  - A link to a page where the issue is present (Like JSFiddle or similar).
  - A .zip file containing a page where the issue is present.

Yes, you really need to share a page, way to often the issues are due to some dependency, so you will be ignored if you don't.